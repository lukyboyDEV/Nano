// Only the local start page (file://) gets this API; websites never do.
const { contextBridge, ipcRenderer } = require('electron');
if (location.protocol === 'file:') {
  contextBridge.exposeInMainWorld('nano', {
    getEngine: () => ipcRenderer.invoke('engine:get'),
    setEngine: id => ipcRenderer.send('engine:set', id),
    web: q => ipcRenderer.invoke('nano:search', q),
    ai: o => ipcRenderer.invoke('nano:ai', o),
    search: q => ipcRenderer.send('start:search', q),
    chat: o => ipcRenderer.invoke('nano:chat', o),
    open: (page, q) => ipcRenderer.send('start:open', page, q)
  });
}
