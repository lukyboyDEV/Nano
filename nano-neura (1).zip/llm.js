// Nano local LLM: a real on-device chat model (GGUF via node-llama-cpp). No API key, no cost, nothing leaves the machine.
const path = require('path'), fs = require('fs');
const MODEL_FILE = 'model.gguf';
let NAME = 'Nano NEURA 1 lite';
for (const d of [process.resourcesPath && path.join(process.resourcesPath, 'model'), path.join(__dirname, 'model')].filter(Boolean)) { try { NAME = JSON.parse(fs.readFileSync(path.join(d, 'variant.json'), 'utf8')).name; break; } catch {} }
const SYSTEM = 'You are ' + NAME + ', the friendly built-in AI assistant of the Nano browser by VANTA. You run fully on the user\'s device. Answer clearly and concisely. If you are unsure, say so instead of guessing.';
const dirs = () => [process.resourcesPath && path.join(process.resourcesPath, 'model'), path.join(__dirname, 'model')].filter(Boolean);
const modelPath = () => { for (const d of dirs()) { const p = path.join(d, MODEL_FILE); if (fs.existsSync(p)) return p; } return null; };

let ctxP = null, session = null, queue = Promise.resolve();
async function load() {
  const p = modelPath(); if (!p) throw new Error('model missing');
  const { getLlama, LlamaChatSession } = await import('node-llama-cpp');
  const llama = await getLlama();
  const model = await llama.loadModel({ modelPath: p });
  const context = await model.createContext({ contextSize: 4096 });
  return { LlamaChatSession, context };
}
// history: [{role:'user'|'assistant', text}] -> reply text. Calls are serialized (one model, one answer at a time).
function reply(history, onToken) {
  const job = queue.then(async () => {
    ctxP = ctxP || load().catch(e => { ctxP = null; throw e; });
    const { LlamaChatSession, context } = await ctxP;
    const msgs = history.slice(-12), last = msgs.pop();
    if (!last || last.role !== 'user') throw new Error('no user message');
    if (session) { try { session.dispose({ disposeSequence: true }); } catch {} }
    session = new LlamaChatSession({ contextSequence: context.getSequence(), systemPrompt: SYSTEM });
    session.setChatHistory([{ type: 'system', text: SYSTEM }, ...msgs.map(m => m.role === 'user' ? { type: 'user', text: m.text } : { type: 'model', response: [m.text] })]);
    return (await session.prompt(last.text, { maxTokens: 700, temperature: 0.6, onTextChunk: onToken })).trim();
  });
  queue = job.catch(() => {});
  return job;
}
module.exports = { name: NAME, reply, available: () => !!modelPath() };
