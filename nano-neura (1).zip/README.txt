Nano — by VANTA

Build the installer: double-click "Build Nano Setup.vbs" (Windows). Needs internet the first time.
Run from source: npm install, then npm start.

Shortcuts: Ctrl+T new tab, Ctrl+W close, Ctrl+L address bar, Ctrl+R / F5 reload,
Ctrl+Tab next tab, Ctrl+1-9 jump to tab, Alt+Left/Right back/forward.

Nano Brain: Nano's own on-device AI (brain.js). It writes the AI overview on Nano Seek and powers the
chat pinned on the new tab page (also reachable by typing nano://chat in the address bar).

Local LLM: chat now runs a real on-device model (Qwen2.5-1.5B, ~1 GB, node-llama-cpp). It is downloaded once at build time
(npm run model) and bundled into the installer - no API key, no cost. Replies are slower on weak CPUs. Set NANO_MODEL_URL to use a different GGUF.
If the model is missing, chat falls back to the old Nano Brain search engine.

Editions: build.bat (or the .vbs) builds Nano NEURA 1 lite (1.5B model, ~1 GB). 'Build NEURA 1.bat' builds Nano NEURA 1 (3B model, ~1.7 GB, smarter, slower).
