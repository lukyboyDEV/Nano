// Downloads the bundled chat model (~1 GB, Qwen2.5-1.5B-Instruct Q4_K_M) into ./model/model.gguf. Skips if present.
const https = require('https'), fs = require('fs'), path = require('path');
const V = { lite: { name: 'Nano NEURA 1 lite', url: 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf' },
  full: { name: 'Nano NEURA 1', url: 'https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q3_k_m.gguf' } };
const vk = process.argv[2] === 'full' ? 'full' : 'lite', URL_ = process.env.NANO_MODEL_URL || V[vk].url;
const dir = path.join(__dirname, '..', 'model'), out = path.join(dir, 'model.gguf');
fs.mkdirSync(dir, { recursive: true });
const vf = path.join(dir, 'variant.json'); let cur = ''; try { cur = JSON.parse(fs.readFileSync(vf, 'utf8')).key; } catch {}
if (cur && cur !== vk) try { fs.unlinkSync(out); } catch {}
fs.writeFileSync(vf, JSON.stringify({ key: vk, name: V[vk].name }));
if (fs.existsSync(out) && fs.statSync(out).size > 5e8) { console.log('Model already present.'); process.exit(0); }
function get(u, n = 0) {
  https.get(u, { headers: { 'User-Agent': 'nano-build' } }, r => {
    if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && n < 8) return get(new URL(r.headers.location, u).href, n + 1);
    if (r.statusCode !== 200) { console.error('Download failed: HTTP ' + r.statusCode); process.exit(1); }
    const total = +r.headers['content-length'] || 0, tmp = out + '.part'; let got = 0, last = 0;
    r.on('data', c => { got += c.length; if (Date.now() - last > 2000) { last = Date.now(); process.stdout.write(`\r${(got / 1e6).toFixed(0)} / ${(total / 1e6).toFixed(0)} MB`); } });
    r.pipe(fs.createWriteStream(tmp)).on('finish', () => { fs.renameSync(tmp, out); console.log('\nModel ready.'); });
  }).on('error', e => { console.error(e.message); process.exit(1); });
}
console.log('Downloading chat model...'); get(URL_);
